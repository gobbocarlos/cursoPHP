<?php
namespace src\controllers;
use \core\Controller;
use \src\handlers\UserHandler;
use \src\handlers\PostHandler;
use \src\Models\Jogo;
class AjaxController extends Controller {
    private $loggedUser;
    public function __construct(){
        $this->loggedUser = UserHandler::checkLogin();
        if( $this->loggedUser===false){
           header("Content-Type: application/json");
           echo json_encode(['error'=>'usuário não logado.']);
           exit;
        }
        
    }
   public function dadosjogo(){
        $array = ['error'=>''];   
        // $id = filter_input(INPUT_POST,'id');
        // $quadro = filter_input(INPUT_POST,'quadro');
        // $adversario = filter_input(INPUT_POST,'adversario');
        // $data = filter_input(INPUT_POST,'dataJogo');
        // $golsPro = filter_input(INPUT_POST,'gp');
        // $golsContra = filter_input(INPUT_POST,'gc');
        // $local = filter_input(INPUT_POST,'local');


        /*
            Você está enviando um json na requisição, não consegue acessar diretament por POST tem que fazer o parse, e só depois fazer as validações (Falta validar os dados, deve fazer isso depois, deixei funcionar para ver a edição funcionando)
        */
        $data_inputs = json_decode(file_get_contents('php://input'), true);
        
        /*
            Verifica se no json após o parse existe algum dado
        */
        if (is_array($data_inputs) && !empty($data_inputs)) {


            /*
                Aqui preenchemos as variaveis (Fazer validação dos dados)
            */
            $id = $data_inputs['id'];
            $quadro = $data_inputs['quadro'];
            $adversario = $data_inputs['adversario'];
            $data = $data_inputs['dataJogo'];
            $golsPro =$data_inputs['gp'];
            $golsContra = $data_inputs['gc'];
            $local = $data_inputs['local'];  

            /*
                Aqui variaveis estavam com nomes errados (Comparar com seu código)
            */
            Jogo::update([
                'quadro' => $quadro,
                'adversario'=>$adversario,
                'data'=>$data,
                'golspro'=>$golsPro,
                'golscontra'=>$golsContra,
                'local'=>$local
            ])->where('id',$id)->execute();
            
            $array['id']= $id;
            $array['quadro']=$quadro;
            $array['adversario']=$adversario;
            $array['data']=$data;
            $array['golsPro']=$golsPro;
            $array['golsContra']=$golsContra;
            $array['local']=$local;
        } else {
            $array['error'] = "Dados não enviados";
        }

        header("Content-Type: application/json");   
        echo json_encode($array);
        exit;
   }
  /* public function comment(){
    $array = ['error'=>''];   
    $id= filter_input(INPUT_POST,'id');
       $txt= filter_input(INPUT_POST,'txt');
       if($id && $txt){
            PostHandler::addComment($id,$txt,$this->loggedUser->id);
            $array['link'] = '/perfil/'.$this->loggedUser->id ;
            $array['avatar'] = '/images/avatars/'.$this->loggedUser->avatar;
            $array['name'] = $this->loggedUser->name;
            $array['body'] = $txt;
       }
       header("Content-Type: application/json");
           echo json_encode($array);
           exit;
   }*/
  /* public function upload(){
       $array=['error'=>''];
        if(isset($_FILES['photo'])$$ !empty($_FILES['photo']['tmp_name'])){
            $photo = $_FILES['photo'];
            $maxWidth = 800;
            $maxHeight = 800;
            if(in_array($photo['type'],['image/png,image/jpg,image/jpeg'])){
                list($widthOrig,$heightOrig) = getsizeimage($photo['tmp_name']);
                $ratio = $widthOrig/$heightOrig;
                $newWidth = $maxWidth;
                $newHeight = $maxHeight;
                $ratioMax = $maxWidth/$maxHeight;
                if($ratioMax>$ratio){
                    $newWidth = $newHeight * $ratio;
                }else{
                    $newHeight = $newWidth * $ratio;
                }
                $finalImage = imagecreatortruecolor($newWidth,$newHeight);
                switch($photo['type']){
                    case 'image/png':
                        $image = imagecreatefrompng($photo['tmp_name']);
                    break;
                    case 'image/jpg':
                    case 'image/jpeg':
                        $image = imagecreatefromjpeg($photo['tmp_name']);
                    break;
                }
                imagecopyresampled(
                    $finalImage,$image,
                    0,0,0,0,
                    $newWidth,$newHeight,$widthOrig,$heightOrig
                );
                $photoName = md5(time().tand(0,9999)).'jpg';
                imagejpeg($finalImage,'media/uploads/'.$photoName);
                PostHandler::addPost($this->loggedUSer->id,'photo',$photoName);
            }
        }else{
            $array['error']='Nenhuma imagem enviada.';
        }

       header("Content-Type: application/json");
           echo json_encode($array);
           exit;

   }*/
}